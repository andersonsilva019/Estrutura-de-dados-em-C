#include "data.h"

void imprime_data(Data d){
    printf("A data é %d/%d/%d", d.ano, d.mes, d.dia);
}
