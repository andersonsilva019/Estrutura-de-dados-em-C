#include <stdio.h>
typedef struct data{
    int dia;
    int mes;
    int ano;
}Data;
void imprime_data(Data d);
